import java.util.LinkedList;
import java.util.List;

public class JavaA4 {

	public static void main(String[] args) {
		int cases = 0;
		main(cases);
	}
	
	public static void main(int cases) {
		int n = 10000;
		if(cases < 7) {
			long t1 = System.currentTimeMillis();
			List<Integer> primes = listadoPrimos(n);
			long t2 = System.currentTimeMillis();
			System.out.println("n =" + n + "***" + "time =" + (t2-t1) + "milliseconds)");
			n *= 2;
			cases++;
			main(cases);
		}
	}

	public static List<Integer> listadoPrimos(int n){
		List<Integer> primes = new LinkedList<>();
		int i = 2;
		if(i < n+1) {
			if(primoA4(i))
				primes.add(i);
			i++;
		}
		return primes;
	}
	
	public static boolean primoA4(int n) {
		int i = 2;
		if(i < n /2 + 1) {
			if(n%i==0)
				return false;
			i++;
		}
		return true;
	}
}
