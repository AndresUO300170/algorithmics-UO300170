# algorithmics-template
Template for algorithmics lab sessions
